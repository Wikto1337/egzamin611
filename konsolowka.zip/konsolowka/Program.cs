using System;

namespace konsolowka
{
    class TablicaOperacje
    {
        private int[] tablica;
        private int liczbaElementow;

        public TablicaOperacje(int rozmiar)
        {
            liczbaElementow = rozmiar;
            tablica = new int[liczbaElementow];

            Random rand = new Random();
            for (int i = 0; i < liczbaElementow; i++)
            {
                tablica[i] = rand.Next(1, 1000);
            }
        }
        public void WyswietlElementy()
        {
            for (int i = 0; i < liczbaElementow; i++)
            {
                Console.WriteLine(tablica[i]);
            }
        }

        public int Wyszukaj(int szukanaWartosc)
        {
            for (int i = 0; i < liczbaElementow; i++)
            {
                if (tablica[i] == szukanaWartosc)
                {
                    return i;
                }
            }
            return -1;
        }
        public int WyswietlNieparzyste()
        {
            int licznikNieparzystych = 0;
            Console.WriteLine("Nieparzyste elementy tablicy:");

            for (int i = 0; i < liczbaElementow; i++)
            {
                if (tablica[i] % 2 != 0)
                {
                    Console.WriteLine(tablica[i]);
                    licznikNieparzystych++;
                }
            }
            return licznikNieparzystych;
        }
        public double LiczSrednia()
        {
            if (liczbaElementow == 0) 
                { return 0; }

            double suma = 0;
            for (int i = 0;i < liczbaElementow; i++)
            {
                suma += tablica[i];
            }
            return suma/liczbaElementow;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int rozmiarTablicy = 25;
            TablicaOperacje operacje = new TablicaOperacje(rozmiarTablicy);

            Console.WriteLine("Wszystkie elementy tablicy");
            operacje.WyswietlElementy();
            Console.WriteLine();

            int szukana = 588;
            int wynikWyszukiwania = operacje.Wyszukaj(szukana);
            if(wynikWyszukiwania != 0)
            {
                Console.WriteLine($"{wynikWyszukiwania}: {szukana}");
            }
            Console.WriteLine();

            int iloscNieparzystych = operacje.WyswietlNieparzyste();
            Console.WriteLine($"Razem nieparzystych: {iloscNieparzystych}");
            Console.WriteLine();

            double srednia = operacje.LiczSrednia();
            Console.WriteLine($"Średnia wszystkich elementów: {srednia}");
            Console.WriteLine();
        }
    }
}